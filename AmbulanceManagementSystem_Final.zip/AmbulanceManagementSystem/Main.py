import Shortest_path as py

if __name__ == "__main__":
    py.main()